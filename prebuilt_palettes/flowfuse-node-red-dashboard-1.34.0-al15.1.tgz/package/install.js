const {spawnSync}=require("child_process");
const fs=require("fs"),path=require("path");
const root=__dirname,payload=path.join(root,"payload.tar.gz");
if(!fs.existsSync(payload)){console.error("Offline payload missing");process.exit(1);}
const r=spawnSync("tar",["-xzf",payload,"-C",root],{stdio:"inherit",env:process.env});
if(r.error||r.status!==0){console.error("Payload extraction failed",r.error||r.status);process.exit(r.status||1);}
try{fs.unlinkSync(payload);}catch(e){console.warn("Payload cleanup failed",e.message);}
const p=JSON.parse(fs.readFileSync(path.join(root,"package.json"),"utf8"));
const missing=Object.values((p["node-red"]||{}).nodes||{}).filter(f=>!fs.existsSync(path.join(root,f)));
if(missing.length){console.error("Node files missing",missing);process.exit(1);}
console.log("Offline runtime installed successfully.");
