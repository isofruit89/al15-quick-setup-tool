const { spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const packageRoot = __dirname;
const payload = path.join(packageRoot, "payload.tar.gz");

if (!fs.existsSync(payload)) {
    console.error("AL15 offline payload is missing:", payload);
    process.exit(1);
}

console.log("Extracting AL15 OPC UA offline runtime...");

const result = spawnSync(
    "tar",
    ["-xzf", payload, "-C", packageRoot],
    {
        stdio: "inherit",
        env: process.env
    }
);

if (result.error) {
    console.error("Unable to execute tar:", result.error.message);
    process.exit(1);
}

if (result.status !== 0) {
    console.error("Payload extraction failed with exit code:", result.status);
    process.exit(result.status || 1);
}

try {
    fs.unlinkSync(payload);
} catch (error) {
    console.warn("Payload could not be removed:", error.message);
}

const opcuaFile = path.join(packageRoot, "opcua", "101-opcuaitem.js");
const nodeOpcuaFile = path.join(
    packageRoot,
    "node_modules",
    "node-opcua",
    "package.json"
);

if (!fs.existsSync(opcuaFile) || !fs.existsSync(nodeOpcuaFile)) {
    console.error("Offline runtime validation failed after extraction.");
    process.exit(1);
}

console.log("AL15 OPC UA offline runtime installed successfully.");
